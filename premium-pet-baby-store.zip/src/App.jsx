import React, { useState } from 'react';

const PRODUCTS = [
  {
    id: 'luxury-cat-tree',
    title: 'Luxury Multi-Level Cat Tree',
    category: 'pet',
    price: 249,
    img: 'https://images.unsplash.com/photo-1619983081563-d5d8b6e5be83?q=80&w=800&auto=format&fit=crop',
    description: 'Premium wooden cat tree with hammocks, sisal posts, and cozy hideouts — perfect for spoiled kitties.',
    payhip: 'https://payhip.com/b/ABC123'
  },
  {
    id: 'smart-pet-feeder',
    title: 'Smart WiFi Pet Feeder',
    category: 'pet',
    price: 189,
    img: 'https://images.unsplash.com/photo-1601758125946-6ec2e6ff9a63?q=80&w=800&auto=format&fit=crop',
    description: 'Automatic feeder with portion control, HD camera, and app control for busy pet parents.',
    payhip: 'https://payhip.com/b/DEF456'
  },
  {
    id: 'ergonomic-baby-carrier',
    title: 'Ergonomic Baby Carrier with Hip Seat',
    category: 'baby',
    price: 139,
    img: 'https://images.unsplash.com/photo-1598473515514-3b66d6c5ae88?q=80&w=800&auto=format&fit=crop',
    description: 'Supportive, breathable carrier for newborns to toddlers — perfect for long walks and hands-free comfort.',
    payhip: 'https://payhip.com/b/GHI789'
  },
  {
    id: '4k-baby-monitor',
    title: '4K Ultra HD Baby Monitor',
    category: 'baby',
    price: 299,
    img: 'https://images.unsplash.com/photo-1613983138006-b3a9d889e836?q=80&w=800&auto=format&fit=crop',
    description: 'Crystal clear video, night vision, two-way audio, and app connectivity to keep your baby safe 24/7.',
    payhip: 'https://payhip.com/b/JKL012'
  },
  {
    id: 'matching-family-pajamas',
    title: 'Matching Family & Pet Pajamas',
    category: 'combo',
    price: 99,
    img: 'https://images.unsplash.com/photo-1607356925286-cb9f3c4061f5?q=80&w=800&auto=format&fit=crop',
    description: 'Festive and cozy matching pajamas for the whole family — including your furry friends.',
    payhip: 'https://payhip.com/b/MNO345'
  },
  {
    id: 'custom-pet-portrait',
    title: 'Custom Hand-Painted Pet Portrait',
    category: 'pet',
    price: 159,
    img: 'https://images.unsplash.com/photo-1560807707-8cc77767d783?q=80&w=800&auto=format&fit=crop',
    description: 'Beautiful, hand-painted artwork of your pet — the ultimate keepsake gift.',
    payhip: 'https://payhip.com/b/PQR678'
  }
];

export default function PremiumPetBabyShop() {
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('all');

  const filtered = PRODUCTS.filter((p) => {
    const q = query.trim().toLowerCase();
    const matchQuery = q === '' || p.title.toLowerCase().includes(q) || p.description.toLowerCase().includes(q);
    const matchCategory = category === 'all' || p.category === category;
    return matchQuery && matchCategory;
  });

  function openPayhip(url) {
    if (!url) {
      window.alert('This product is not linked to Payhip yet. Replace the payhip URL in the product data.');
      return;
    }
    window.open(url, '_blank', 'noopener');
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-gray-50 text-gray-900">
      <header className="sticky top-0 bg-white border-b shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div>
            <h1 className="text-xl font-extrabold tracking-tight">Premium Pet & Baby Shop</h1>
            <p className="text-xs text-gray-500">Payhip-powered checkout — replace product links before going live.</p>
          </div>

          <div className="flex items-center gap-2">
            <input
              aria-label="Search products"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search products..."
              className="border rounded px-3 py-1 text-sm focus:outline-none focus:ring"
            />

            <select
              aria-label="Filter by category"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="border rounded px-2 py-1 text-sm focus:outline-none focus:ring"
            >
              <option value="all">All</option>
              <option value="pet">Pet</option>
              <option value="baby">Baby</option>
              <option value="combo">Matching Sets</option>
            </select>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {filtered.length === 0 && (
          <p className="text-center text-gray-500">No products match your search.</p>
        )}

        <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((product) => (
            <article key={product.id} className="bg-white rounded-lg shadow hover:shadow-md overflow-hidden">
              <img src={product.img} alt={product.title} className="w-full h-56 object-cover" />

              <div className="p-4 flex flex-col h-full">
                <h4 className="font-semibold text-lg">{product.title}</h4>
                <p className="text-sm text-gray-500 mt-1 flex-grow">{product.description}</p>

                <div className="mt-3 flex items-center justify-between">
                  <div className="font-bold text-lg">${product.price}</div>
                  <div className="text-xs text-gray-400">Fast personalization available</div>
                </div>

                <div className="mt-4 flex gap-2">
                  <button
                    type="button"
                    onClick={() => openPayhip(product.payhip)}
                    className="flex-1 bg-green-600 text-white rounded py-2 font-semibold hover:bg-green-700 transition"
                  >
                    Buy Now
                  </button>

                  <button
                    type="button"
                    onClick={() => window.alert('Send us an email at support@youremail.com to request personalization options.')}
                    className="px-3 py-2 border rounded text-sm"
                  >
                    Personalize
                  </button>
                </div>
              </div>
            </article>
          ))}
        </section>
      </main>

      <footer className="border-t bg-white mt-12">
        <div className="max-w-7xl mx-auto px-4 py-6 text-sm text-gray-600">
          <div>Replace the placeholder Payhip product URLs in the PRODUCTS array before going live.</div>
          <div className="mt-2">Need help deploying? Ask me to push this to GitHub and I can provide Vercel/Netlify deploy steps.</div>
        </div>
      </footer>
    </div>
  );
}
