# Premium Pet & Baby Shop

This is a React + Vite single-page app for a pet & baby product store connected to Payhip for direct sales.

## Setup

- Run `npm install` to install dependencies
- Run `npm run dev` to start local dev server
- Run `npm run build` to build production files

## Deploy

Deploy on Vercel, Netlify, or your favorite static hosting. Make sure to replace placeholder Payhip URLs in `src/App.jsx` with your actual product links before going live.
